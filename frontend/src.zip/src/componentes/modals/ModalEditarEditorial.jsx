
import React, { useEffect } from 'react';
import './ModalEditorial.css';
import useEditorial from '/src/hooks/useEditorial';

export default function ModalEditarEditorial({ editorial, alCerrar, alGuardar }) {
  const [datos, setDato] = useEditorial();

  // Cargar los datos de la editorial cuando el modal se abre
  useEffect(() => {
    if (editorial) {
      setDato('id', editorial.id);
      setDato('nombre', editorial.nombre);
      setDato('pais', editorial.pais);
    }
  }, [editorial]);

  const manejarEnvio = (e) => {
    e.preventDefault();
    
    // Validaciones
    if (!datos.nombre.trim()) {
      alert('El nombre de la editorial es obligatorio');
      return;
    }
    if (!datos.pais.trim()) {
      alert('El país es obligatorio');
      return;
    }

    alGuardar(datos);
  };

  return (
    <div className="modal-overlay-editorial" onClick={alCerrar}>
      <div className="modal-editorial-container" onClick={(e) => e.stopPropagation()}>
        
        
        <button className="boton-volver-editorial" onClick={alCerrar}>VOLVER</button>

        <form onSubmit={manejarEnvio} className="formulario-editorial">
          <h2 className="titulo-campo-editorial">Editorial</h2>
          <input
            type="text"
            value={datos.nombre}
            onChange={(e) => setDato('nombre', e.target.value)}
            className="campo-input-editorial"
            placeholder="LibroTeca"
          />

          <h2 className="titulo-campo-editorial">Pais</h2>
          <input
            type="text"
            value={datos.pais}
            onChange={(e) => setDato('pais', e.target.value)}
            className="campo-input-editorial"
            placeholder="Argentino"
          />

          <button type="submit" className="boton-editar-editorial">
            Editar
          </button>
        </form>
      </div>
    </div>
  );
}