import React from 'react';



const Prueba = () => {
     
    return (
       <h1>fuera de todo</h1>

    );
};
export default Prueba;